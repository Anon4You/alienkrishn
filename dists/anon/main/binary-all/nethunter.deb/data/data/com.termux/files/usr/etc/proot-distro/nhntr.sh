# Official Kali Nethunter for termux
# Do not change this code
DISTRO_NAME="Kali Linux (Nethunter)"
DISTRO_COMMENT="Kali minimal rolling release"

TARBALL_URL['aarch64']="https://kali.download/nethunter-images/current/rootfs/kalifs-arm64-minimal.tar.xz"
TARBALL_SHA256['aarch64']="c4d1d8be66c243d94ce21fd61ba5ab55bbd8fd5d105c1888402016864a6f0490"
TARBALL_URL['arm']="https://kali.download/nethunter-images/current/rootfs/kalifs-armhf-minimal.tar.xz"
TARBALL_SHA256['arm']="fdcc33165e8bb0d1fee0070422e34c17e2cf8265efca1c049e944d40ca042916"
