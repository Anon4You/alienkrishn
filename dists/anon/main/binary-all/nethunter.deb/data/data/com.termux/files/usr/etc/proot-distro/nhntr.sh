# Official Kali Nethunter for termux
# Do not change this code
DISTRO_NAME="Kali Linux (Nethunter)"
DISTRO_COMMENT="Kali minimal rolling release"

TARBALL_URL['aarch64']="https://kali.download/nethunter-images/current/rootfs/kalifs-arm64-minimal.tar.xz"
TARBALL_SHA256['aarch64']="0560e294fef5fdbadf077bdd609166c94f68f4be72429ba366b4fe4146694dee"
TARBALL_URL['arm']="https://kali.download/nethunter-images/current/rootfs/kalifs-armhf-minimal.tar.xz"
TARBALL_SHA256['arm']="a9d75f84a5509fd1e85d3bacabc114c5f6def9f9673b1399c97091b6a64e8bb1"
