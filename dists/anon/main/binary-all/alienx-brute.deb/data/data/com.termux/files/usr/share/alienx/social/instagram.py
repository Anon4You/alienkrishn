#!/usr/bin/python
import os,sys,time 
print("Not working now...updating soon")
time.sleep(3)
os.system("exit")
