import hashlib 
import os
import random
import binascii
import datetime
starttime = datetime.datetime.now()
def ntlm_attack(filestring):
    input2 = raw_input("\033[4mAlienx\033[0m set(\033[91mhash/ntlm\033[0m) > ")

    with open(filestring) as file: # Use file to refer to the file object
        for i in enumerate(file):    
            i = i[1].rstrip("\n")
            
            try:
                passhash = hashlib.new('md4', i.encode('utf-16le')).digest()
                passhash = binascii.hexlify(passhash)
            except UnicodeDecodeError:
                print("unicode error found, a character probably isnt english: " + i)
            
            if(str(passhash).upper() == input2.upper()):
                pwdfile = open(filepath,'r')
                for passowrd in pwdfile:
                    print "\033[91mChecking passowrd: %s\033[0m" % (passowrd.strip())
                print("\033[92mPassword found! Password is:\033[0m " + i)
                file.close()
                break
#            else:
 #               print "Password not found!"
    file.close()
    endtime = datetime.datetime.now()
    timedifference = endtime-starttime;
    a = divmod(timedifference.days * 86400 + timedifference.seconds, 60)
#    print str(a[0])+":"+str(a[1])
filepath = raw_input("\033[4mAlienx\033[0m set(\033[91mwordlist/path\033[0m) > ")
ntlm_attack(filepath)
