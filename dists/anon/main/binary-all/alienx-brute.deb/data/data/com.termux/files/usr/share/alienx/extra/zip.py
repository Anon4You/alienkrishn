#!/usr/bin/python
import os, sys, zipfile
try:
    import tqdm
except:
    os.system("pip install tqdm")
from tqdm import tqdm
# user input zipfile and wordlist
zip=input("\033[4mAlienx\033[0m set(\033[32menter/zip\033[0m) > ")#storing in variable
pswd=input("\033[4mAlienx\033[0m set(\033[32mpass/path/dir\033[0m) > ") #storing in variable

zip_file=zipfile.ZipFile(zip)
words=len(list(open(pswd,"rb")))
print("\33[33;1m\nCracking password please wait...\33[0m")

with open(pswd,"rb") as wordlist:
    for word in tqdm(wordlist, total=words, unit=" words"):
        try:
            zip_file.extractall(pwd=word.strip())
        except:
            continue
        else:
            print("[✓]\33[32mPassword Found...\33[0m",word.decode().strip())
            exit(0)

print("[x]Password not found, try onether wordlist...")
