#!/usr/bin/python
import os,sys,time
from tqdm import tqdm 
try:
    import pikepdf
except:
    os.system("pip install pikepdf")
import pikepdf 
ipdf=input("\033[4mAlienx\033[0m set(\033[32menter/pdf\033[0m) > ")
pswd=input("\033[4mAlienx\033[0m set(\033[32mpass/path/dir\033[0m) > ")
passwords = [ line.strip() for line in open(pswd) ]
print("\33[36mCracking PDF with Custom wordlist..\33[0m")
for password in tqdm(passwords, "Decrypting "):
  try:
     with pikepdf.open(ipdf, password=password) as pdf:
       print("\n\a\a\33[32;1m[+] Password found:\33[0m", password)
     break
  except pikepdf.PasswordError as e:
    continue

